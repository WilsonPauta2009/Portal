﻿using Infragistics.Web.UI.ListControls;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Reporting;
using Telerik.Web.UI;

public partial class Ventas_FrmPreciador : System.Web.UI.Page
{
    ClsVentas objPreciador = new ClsVentas();
    WebDropDown wdpEmpr;
    WebDropDown wdpSucu;
    Label lblTemp;
    PlantillaVentas o = new PlantillaVentas();
    List<clsProduct> product = new List<clsProduct>();    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            lblTemp = (Label)Master.FindControl("lblDiv");
            lblTemp.Visible = true;
            lblTemp = (Label)Master.FindControl("lblSuc");
            lblTemp.Visible = true;
            wdpEmpr = (WebDropDown)Master.FindControl("wdpEmpr");
            wdpEmpr.Visible = true;
            wdpSucu = (WebDropDown)Master.FindControl("wdpSuc");
            wdpSucu.Visible = true;
            o.loadEmpr(wdpEmpr, wdpSucu, Session["iden"].ToString());
            objPreciador.WEBLoadClasifica(rcbLinea, wdpEmpr.SelectedValue, int.Parse(wdpSucu.SelectedValue), "LINE");
            objPreciador.WEBLoadClasifica(rcbMarca, wdpEmpr.SelectedValue, int.Parse(wdpSucu.SelectedValue), "MARC");
            objPreciador.WEBLoadClasifica(rcbSeccion, wdpEmpr.SelectedValue, int.Parse(wdpSucu.SelectedValue), "SECC");
            objPreciador.WEBLoadClasifica(rcbSubs, wdpEmpr.SelectedValue, int.Parse(wdpSucu.SelectedValue), "SUBS");
            Session["products"] = new List<clsProduct>();
            //objPreciador.WEBLoadClasifica(rcbLinea, ClsDatos.mEmpr, 2128, "LINE");
            //objPreciador.WEBLoadClasifica(rcbMarca, ClsDatos.mEmpr, 2128, "MARC");
            //objPreciador.WEBLoadClasifica(rcbSubs, ClsDatos.mEmpr, 2128, "SUBS");
            //objPreciador.WEBLoadClasifica(rcbSeccion, ClsDatos.mEmpr, 2128, "SECC");
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        var master = (PlantillaVentas)Page.Master;
        master.OnSomethingSelected += MasterSelected;
    }

    private void MasterSelected(object sender, string selectedValue)
    {
        wdpEmpr = (WebDropDown)Master.FindControl("wdpEmpr");
        // now you can handle the master's event and update your content page
        objPreciador.WEBLoadClasifica(rcbLinea, wdpEmpr.SelectedValue, int.Parse(selectedValue), "LINE");
        objPreciador.WEBLoadClasifica(rcbMarca, wdpEmpr.SelectedValue, int.Parse(selectedValue), "MARC");
        objPreciador.WEBLoadClasifica(rcbSeccion, wdpEmpr.SelectedValue, int.Parse(selectedValue), "SECC");
        objPreciador.WEBLoadClasifica(rcbSubs, wdpEmpr.SelectedValue, int.Parse(selectedValue), "SUBS");
    }
    
    protected void btnFiltrar_Click(object sender, EventArgs e)
    {
        wdpEmpr = (WebDropDown)Master.FindControl("wdpEmpr");
        wdpSucu = (WebDropDown)Master.FindControl("wdpSuc");
        rdgProds.DataSource = objPreciador.pkg_getProductos(rcbLinea.SelectedValue, rcbMarca.SelectedValue, rcbSeccion.SelectedValue, rcbSubs.SelectedValue, wdpEmpr.SelectedValue, wdpSucu.SelectedValue, txtpIden.Text, txtObse.Text);
        rdgProds.DataBind();
        TypeReportSource reportSource = new TypeReportSource();
        //switch(rdbList.SelectedValue){
        //    case "1":
        //        reportSource.TypeName = typeof(Preciador.Lista1).AssemblyQualifiedName;
        //        break;
        //    case "2":
        //        reportSource.TypeName = typeof(Preciador.Lista2).AssemblyQualifiedName;
        //        break;
        //    case "3":
        //        reportSource.TypeName = typeof(Preciador.Lista3).AssemblyQualifiedName;
        //        break;
        //}
        reportSource.Parameters.Add("LINE", rcbLinea.SelectedValue);
        reportSource.Parameters.Add("MARC", rcbMarca.SelectedValue);
        reportSource.Parameters.Add("SECC", rcbSeccion.SelectedValue);
        reportSource.Parameters.Add("SUBS", rcbSubs.SelectedValue);
        reportSource.Parameters.Add("ESQU", wdpEmpr.SelectedValue);
        reportSource.Parameters.Add("AREA", wdpSucu.SelectedValue);
        reportSource.Parameters.Add("IDEN", txtpIden.Text);
        reportSource.Parameters.Add("OBSE", txtObse.Text);
        reportSource.Parameters.Add("REPT", chkRep.Checked.ToString());
        reportSource.Parameters.Add("SELE", "false");
        reportSource.Parameters.Add("NUME", txtNume.Text == "" ? "0" : txtNume.Text);
        this.ReportViewer1.ReportSource = reportSource;
        ReportViewer1.RefreshData();
        ReportViewer1.RefreshReport();
    }

    protected void rdbList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnFiltrar_Click(null, null);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //ReportViewer1.Report.Reports.
    }

    protected void chkRep_CheckedChanged1(object sender, EventArgs e)
    {
        if(chkRep.Checked)
            txtNume.Enabled = true;
        else
            txtNume.Enabled = false;
    }
    protected void rdgProds_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        //wdpEmpr = (WebDropDown)Master.FindControl("wdpEmpr");
        //wdpSucu = (WebDropDown)Master.FindControl("wdpSuc");
        //rdgProds.DataSource = objPreciador.pkg_getProductos(rcbLinea.SelectedValue, rcbMarca.SelectedValue, rcbSeccion.SelectedValue, rcbSubs.SelectedValue, wdpEmpr.SelectedValue, wdpSucu.SelectedValue, txtpIden.Text, txtObse.Text);
    }
    
    protected void rdgProds_ItemCommand(object sender, GridCommandEventArgs e)
    {
        //if (e.CommandName == RadGrid.SelectCommandName)
        //{
        //    string a = (e.Item as GridDataItem).GetDataKeyValue("ARTI").ToString();
        //}
    }

    protected void rdgProds_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rdgProds.SelectedItems.Count > 0)
        {
            bool exis = false;
            product = (List<clsProduct>)Session["products"];
            int i = product.Count;
            for (int j = 0; j < i; j++) {
                if (product[j].arti == rdgProds.SelectedValues["ARTI"].ToString())
                {
                    exis = true;
                    break;
                }
                else
                    exis = false; 
            }
            if (!exis)
            {
                product.Add(new clsProduct()
                {
                    index = i + 1,
                    arti = rdgProds.SelectedValues["ARTI"].ToString(),
                    nomb = rdgProds.SelectedValues["NOMB"].ToString(),
                    dlin = rdgProds.SelectedValues["CLIN"].ToString(),
                    dmar = rdgProds.SelectedValues["CMAR"].ToString(),
                    dsec = rdgProds.SelectedValues["CSEC"].ToString(),
                    dsub = rdgProds.SelectedValues["CSUB"].ToString(),
                    prepvp = decimal.Parse(rdgProds.SelectedValues["PREPVP"].ToString()),
                    entr = decimal.Parse(rdgProds.SelectedValues["ENTR"].ToString()),
                    etiEn = rdgProds.SelectedValues["ETIEN"].ToString(),
                    etiPlaz = rdgProds.SelectedValues["ETIPLAZ"].ToString(),
                    etiCuo = rdgProds.SelectedValues["ETICUO"].ToString(),
                    etiPvp = rdgProds.SelectedValues["ETIPVP"].ToString(),
                    tipo = rdgProds.SelectedValues["TIPO"].ToString(),
                    plaz = rdgProds.SelectedValues["PLAZ"].ToString(),
                    pvpf = decimal.Parse(rdgProds.SelectedValues["PVPF"].ToString()),
                    cuot = decimal.Parse(rdgProds.SelectedValues["CUOT"].ToString()),
                    obse = rdgProds.SelectedValues["OBSE"].ToString(),
                });
                Session["products"] = product;
                rdgSelect.DataSource = Session["products"];
                rdgSelect.DataBind();
            }
        }
    }

    protected void rdgSelect_SelectedIndexChanged(object sender, EventArgs e)
    {
        product = (List<clsProduct>)Session["products"];
        var item = product.Single(x => x.arti == rdgSelect.SelectedValues["ARTI"].ToString());
        product.Remove(item);
        Session["products"] = product;
        rdgSelect.DataSource = Session["products"];
        rdgSelect.DataBind();
    }

    protected void rbtGene_Click(object sender, EventArgs e)
    {
        wdpEmpr = (WebDropDown)Master.FindControl("wdpEmpr");
        wdpSucu = (WebDropDown)Master.FindControl("wdpSuc");
        TypeReportSource reportSource = new TypeReportSource();
        //switch (rdbList.SelectedValue)
        //{
        //    case "1":
        //        reportSource.TypeName = typeof(Preciador.Lista1).AssemblyQualifiedName;
        //        break;
        //    case "2":
        //        reportSource.TypeName = typeof(Preciador.Lista2).AssemblyQualifiedName;
        //        break;
        //    case "3":
        //        reportSource.TypeName = typeof(Preciador.Lista3).AssemblyQualifiedName;
        //        break;
        //}
        reportSource.Parameters.Add("ESQU", wdpEmpr.SelectedValue);
        reportSource.Parameters.Add("AREA", wdpSucu.SelectedValue);
        //reportSource.Parameters.Add("IDEN", txtpIden.Text);
        reportSource.Parameters.Add("OBSE", txtObse.Text);
        reportSource.Parameters.Add("REPT", chkRep.Checked.ToString());
        reportSource.Parameters.Add("SELE", "true");

        string line = "";
        string marc = "";
        string secc = "";
        string subs = "";
        string iden = "";
        //string iden = "";
        //string iden = "";
        //string iden = "";
        //string iden = "";
        //string iden = "";
        //string iden = "";

        foreach (GridDataItem item in rdgSelect.Items)
        {
            iden = iden + "*" + item.GetDataKeyValue("ARTI").ToString();
            line = line + "*" + item.GetDataKeyValue("DLIN").ToString();
            marc = marc + "*" + item.GetDataKeyValue("DMAR").ToString();
            secc = secc + "*" + item.GetDataKeyValue("DSEC").ToString();
            subs = subs + "*" + item.GetDataKeyValue("DSUB").ToString();
        }
        reportSource.Parameters.Add("IDEN", iden);
        reportSource.Parameters.Add("NUME", "1");
        reportSource.Parameters.Add("LINE", line);
        reportSource.Parameters.Add("MARC", marc);
        reportSource.Parameters.Add("SECC", secc);
        reportSource.Parameters.Add("SUBS", subs);
        this.ReportViewer1.ReportSource = reportSource;
        ReportViewer1.RefreshData();
        ReportViewer1.RefreshReport();
    }
    protected void rbtClean_Click(object sender, EventArgs e)
    {
        Session["products"] = new List<clsProduct>();
        rdgSelect.DataSource = Session["products"];
        rdgSelect.DataBind();
    }
}