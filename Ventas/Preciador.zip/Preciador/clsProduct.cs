﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Preciador1
{
    public class clsProduct
    {
        public Int64 index { get; set; }

        public string arti { get; set; }

        public string nomb { get; set; }

        public string dlin { get; set; }

        public decimal preofe { get; set; }

        public decimal prepvp { get; set; }

        public string obse { get; set; }

        //public string art_peso { get; set; }

        //public string art_tipo { get; set; }

        //public string art_etec { get; set; }
    }
}