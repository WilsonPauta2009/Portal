﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;

namespace Preciador1
{
    //[DataObject]
    public class clsProducts
    {
        //[DataObjectMethod(DataObjectMethodType.Select)]
        public DataTable loadProductos(params object[] pPArams)
        {
            ClsVentas objVentas = new ClsVentas();
            DataTable tabu = new DataTable();
            tabu = objVentas.pkg_getProductos(pPArams);
            //DataTableReader reader = tabu.CreateDataReader();
            //var products = new List<clsProduct>();
            //products.Clear();
            //while (reader.Read())
            //{
            //    products.Add(new clsProduct()
            //    {
            //        index = reader.GetInt64(0),
            //        arti = reader.GetString(1),
            //        nomb = reader.GetString(2),
            //        dlin = reader.GetString(3),
            //        pre100 = reader.GetDecimal(4),
            //        pre104 = reader.GetDecimal(5)
            //        //art_marc = reader.GetString(5),
            //        //art_peso = reader.GetString(6),
            //        //art_tipo = reader.GetString(7),
            //        //art_etec = reader.GetString(8)
            //    });
            //}
            //reader.Close();
            //return products;
            return tabu;
        }
    }
}