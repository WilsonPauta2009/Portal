namespace Preciador1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;

    /// <summary>
    /// Summary description for Lista3.
    /// </summary>
    public partial class Lista3 : Telerik.Reporting.Report
    {
        public Lista3()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        private void crosstab1_NeedDataSource(object sender, EventArgs e)
        {

        }

        private void Lista3_NeedDataSource(object sender, EventArgs e)
        {
            Telerik.Reporting.Processing.Report rpt = (Telerik.Reporting.Processing.Report)sender;
            string line = rpt.Parameters["LINE"].Value.ToString();
            string marc = rpt.Parameters["MARC"].Value.ToString();
            string secc = rpt.Parameters["SECC"].Value.ToString();
            string subs = rpt.Parameters["SUBS"].Value.ToString();
            string esqu = rpt.Parameters["ESQU"].Value.ToString();
            string area = rpt.Parameters["AREA"].Value.ToString();
            string iden = rpt.Parameters["IDEN"].Value.ToString();
            string obse = rpt.Parameters["OBSE"].Value.ToString();
            bool rept = bool.Parse(rpt.Parameters["REPT"].Value.ToString());
            int nume = int.Parse(rpt.Parameters["NUME"].Value.ToString());
            clsProducts objP = new clsProducts();
            //objectDataSource1.DataMember = "loadProductos";
            if (!rept)
                objectDataSource1.DataSource = objP.loadProductos(line, marc, secc, subs, esqu, area, iden, obse);
            else
            {
                clsProductRep objR = new clsProductRep();
                objectDataSource1.DataSource = objR.loadProductos(nume, line, marc, secc, subs, esqu, area, iden, obse);
            }
        }
    }
}