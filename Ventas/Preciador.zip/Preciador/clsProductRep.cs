﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;

namespace Preciador1
{
    [DataObject]
    public class clsProductRep
    {
        //[DataObjectMethod(DataObjectMethodType.Select)]
        public List<clsProduct> loadProductos(int NumProds, params object[] pPArams)
        {
            ClsVentas objVentas = new ClsVentas();
            DataTable tabu = new DataTable();
            tabu = objVentas.pkg_getProductos(pPArams);
            DataTableReader reader = tabu.CreateDataReader();
            var products = new List<clsProduct>();
            products.Clear();
            while (reader.Read())
            {
                for (int i = 0; i < NumProds; i++)
                {
                    products.Add(new clsProduct()
                    {
                        index = i + 1,
                        arti = reader.GetString(1),
                        nomb = reader.GetString(2),
                        dlin = reader.GetString(3),
                        preofe = reader.GetDecimal(4),
                        prepvp = reader.GetDecimal(5),
                        obse = reader.GetString(6)
                    });
                }

            }
            reader.Close();
            return products;
        }
    }
}